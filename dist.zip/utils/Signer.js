"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.signResponse = void 0;
const crypto_1 = __importDefault(require("crypto"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const privateKeyPath = path_1.default.join(process.cwd(), 'private.pem');
let PRIVATE_KEY = '';
try {
    PRIVATE_KEY = fs_1.default.readFileSync(privateKeyPath, 'utf8');
}
catch (e) {
    console.warn("⚠️  警告: 未找到 private.pem，响应将不会被签名。");
}
const signResponse = (data) => {
    if (!PRIVATE_KEY)
        return { data };
    const payload = JSON.stringify(data);
    const sign = crypto_1.default.createSign('SHA256');
    sign.update(payload);
    sign.end();
    const signature = sign.sign(PRIVATE_KEY, 'base64');
    // 返回标准结构：数据 + 签名
    return { data, signature };
};
exports.signResponse = signResponse;
