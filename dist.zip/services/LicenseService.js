"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LicenseService = void 0;
const client_1 = require("@prisma/client");
const dayjs_1 = __importDefault(require("dayjs"));
const enums_1 = require("../enums");
const prisma = new client_1.PrismaClient();
class LicenseService {
    // 辅助：检查过期并同步数据库
    static checkExpiry(license) {
        return __awaiter(this, void 0, void 0, function* () {
            if (license.expiresAt && (0, dayjs_1.default)().isAfter(license.expiresAt)) {
                if (license.status !== enums_1.LicenseStatus.EXPIRED) {
                    // 懒更新：顺手改状态
                    yield prisma.license.update({ where: { id: license.id }, data: { status: enums_1.LicenseStatus.EXPIRED } });
                }
                throw new Error('授权码已过期');
            }
        });
    }
    /**
     * 场景1：激活/登录 (Login)
     * 只有这一步会执行"挤掉旧机器"的操作
     */
    static activate(key, fingerprint, meta) {
        return __awaiter(this, void 0, void 0, function* () {
            const license = yield prisma.license.findUnique({
                where: { key },
                include: { machines: { orderBy: { lastSeen: 'asc' } } }, // 按时间排序，第0个是最老的
            });
            if (!license)
                throw new Error('授权码无效');
            // 1. 检查过期
            yield this.checkExpiry(license);
            if (license.status !== enums_1.LicenseStatus.ACTIVE)
                throw new Error(`授权码不可用: ${license.status}`);
            // 2. 检查机器是否已存在
            const currentMachine = license.machines.find(m => m.fingerprint === fingerprint);
            if (currentMachine) {
                yield prisma.machine.update({
                    where: { id: currentMachine.id },
                    data: { lastSeen: new Date(), ip: meta.ip },
                });
                return { valid: true, message: '欢迎回来' };
            }
            // 3. 机器不存在，判断是否满员
            if (license.machines.length >= license.maxMachines) {
                if (license.strategy === enums_1.LicenseStrategy.FLOATING) {
                    // === 浮动策略：踢人 ===
                    const machineToKick = license.machines[0];
                    console.log(`[Activate] 浮动踢人: ${machineToKick.fingerprint} 被 ${fingerprint} 挤下线`);
                    // [BUG修复] 使用 deleteMany 避免并发 Race Condition 导致报错
                    yield prisma.machine.deleteMany({ where: { id: machineToKick.id } });
                }
                else {
                    throw new Error('机器数量已达上限');
                }
            }
            // 4. 注册新机器
            yield prisma.machine.create({
                data: {
                    licenseId: license.id,
                    fingerprint,
                    ip: meta.ip,
                    platform: meta.platform,
                    name: meta.hostname,
                },
            });
            return { valid: true, message: '激活成功' };
        });
    }
    /**
     * 场景2：心跳保活 (Heartbeat)
     * 如果被踢，直接报错，不自动重新激活
     */
    static heartbeat(key, fingerprint) {
        return __awaiter(this, void 0, void 0, function* () {
            const license = yield prisma.license.findUnique({
                where: { key },
                include: { machines: { orderBy: { lastSeen: 'asc' } } },
            });
            if (!license)
                throw new Error('授权码无效');
            yield this.checkExpiry(license);
            const currentMachine = license.machines.find(m => m.fingerprint === fingerprint);
            if (!currentMachine) {
                // === 关键：找不到自己 = 被踢了 ===
                throw new Error(enums_1.ErrorCode.KICKED);
            }
            yield prisma.machine.update({
                where: { id: currentMachine.id },
                data: { lastSeen: new Date() },
            });
            return { valid: true, alive: true };
        });
    }
}
exports.LicenseService = LicenseService;
