"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const AuthController_1 = require("./controllers/AuthController");
const AdminController_1 = require("./controllers/AdminController");
const ClientController_1 = require("./controllers/ClientController");
const auth_1 = require("./middleware/auth");
const router = express_1.default.Router();
// Public - Client
router.post('/v1/validate', ClientController_1.ClientController.validate);
router.post('/v1/heartbeat', ClientController_1.ClientController.heartbeat);
// Public - Auth
router.post('/auth/login', AuthController_1.AuthController.login);
// Protected - Admin
router.use('/admin', auth_1.verifyToken);
router.post('/admin/licenses', AdminController_1.AdminController.createLicense);
router.get('/admin/licenses', AdminController_1.AdminController.listLicenses);
router.put('/admin/licenses/:id', AdminController_1.AdminController.updateLicense);
router.delete('/admin/licenses/:id', AdminController_1.AdminController.deleteLicense);
router.delete('/admin/licenses/:id/machines', AdminController_1.AdminController.resetMachines);
router.get('/admin/stats', AdminController_1.AdminController.getStats);
router.get('/admin/machines', AdminController_1.AdminController.listMachines);
exports.default = router;
