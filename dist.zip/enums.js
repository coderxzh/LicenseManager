"use strict";
// src/enums.ts
Object.defineProperty(exports, "__esModule", { value: true });
exports.ErrorCode = exports.LicenseStrategy = exports.LicenseStatus = void 0;
// 授权码状态
var LicenseStatus;
(function (LicenseStatus) {
    LicenseStatus["ACTIVE"] = "ACTIVE";
    LicenseStatus["SUSPENDED"] = "SUSPENDED";
    LicenseStatus["EXPIRED"] = "EXPIRED";
    LicenseStatus["INACTIVE"] = "INACTIVE";
})(LicenseStatus || (exports.LicenseStatus = LicenseStatus = {}));
// 验证策略
var LicenseStrategy;
(function (LicenseStrategy) {
    LicenseStrategy["FLOATING"] = "FLOATING";
    LicenseStrategy["STRICT"] = "STRICT";
})(LicenseStrategy || (exports.LicenseStrategy = LicenseStrategy = {}));
// 错误码 (用于前后端通信)
var ErrorCode;
(function (ErrorCode) {
    ErrorCode["KICKED"] = "SESSION_KICKED";
    ErrorCode["ERROR"] = "ERROR";
})(ErrorCode || (exports.ErrorCode = ErrorCode = {}));
