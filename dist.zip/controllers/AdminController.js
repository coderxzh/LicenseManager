"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminController = void 0;
const client_1 = require("@prisma/client");
const uuid_1 = require("uuid");
const dayjs_1 = __importDefault(require("dayjs"));
const enums_1 = require("../enums");
const prisma = new client_1.PrismaClient();
class AdminController {
    // 生成授权码
    static createLicense(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { days, maxMachines, strategy, remark } = req.body;
                const license = yield prisma.license.create({
                    data: {
                        key: (0, uuid_1.v4)().toUpperCase(),
                        expiresAt: days ? (0, dayjs_1.default)().add(days, 'day').toDate() : null,
                        maxMachines: maxMachines || 1,
                        strategy: strategy || enums_1.LicenseStrategy.FLOATING,
                        remark,
                        status: enums_1.LicenseStatus.ACTIVE,
                    },
                });
                res.json({ success: true, data: license });
            }
            catch (e) {
                res.status(500).json({ error: e.message });
            }
        });
    }
    // 查询列表 (分页 + 搜索 + 状态计算)
    static listLicenses(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const page = parseInt(req.query.page) || 1;
                const pageSize = parseInt(req.query.pageSize) || 10;
                const keyword = req.query.keyword;
                const statusFilter = req.query.status;
                const usageFilter = req.query.usage;
                // 支持按 'expiring' (快过期) 排序
                const sort = req.query.sort === 'expiring' ? { expiresAt: 'asc' } : { createdAt: 'desc' };
                const where = {};
                if (keyword) {
                    // 增强搜索：包括授权码、备注、以及关联设备的指纹/名称/IP
                    where.OR = [
                        { key: { contains: keyword } },
                        { remark: { contains: keyword } },
                        {
                            machines: {
                                some: {
                                    OR: [
                                        { fingerprint: { contains: keyword } },
                                        { name: { contains: keyword } },
                                        { ip: { contains: keyword } },
                                    ],
                                },
                            },
                        },
                    ];
                }
                if (statusFilter)
                    where.status = statusFilter;
                if (usageFilter === 'used')
                    where.machines = { some: {} };
                if (usageFilter === 'unused')
                    where.machines = { none: {} };
                const [total, list] = yield Promise.all([
                    prisma.license.count({ where }),
                    prisma.license.findMany({
                        where,
                        skip: (page - 1) * pageSize,
                        take: pageSize,
                        orderBy: sort,
                        include: { machines: { orderBy: { lastSeen: 'desc' } } },
                    }),
                ]);
                const formattedList = list.map(item => {
                    var _a, _b;
                    const now = (0, dayjs_1.default)();
                    let remainingDays = null;
                    let displayStatus = item.status;
                    if (item.expiresAt) {
                        const exp = (0, dayjs_1.default)(item.expiresAt);
                        remainingDays = exp.diff(now, 'day');
                        // 实时状态修正：如果时间到了，强制显示 EXPIRED
                        if (item.status === enums_1.LicenseStatus.ACTIVE && now.isAfter(exp))
                            displayStatus = enums_1.LicenseStatus.EXPIRED;
                    }
                    else {
                        remainingDays = 99999; // 永久
                    }
                    const isActivated = item.machines.length > 0;
                    // 如果状态是 ACTIVE 但从未激活，显示为 INACTIVE
                    if (displayStatus === enums_1.LicenseStatus.ACTIVE && !isActivated)
                        displayStatus = enums_1.LicenseStatus.INACTIVE;
                    return Object.assign(Object.assign({}, item), { status: displayStatus, rawStatus: item.status, // 保留原始状态
                        remainingDays, isPermanent: !item.expiresAt, usedCount: item.machines.length, isActivated, lastSeenAt: ((_a = item.machines[0]) === null || _a === void 0 ? void 0 : _a.lastSeen) || null, lastIp: ((_b = item.machines[0]) === null || _b === void 0 ? void 0 : _b.ip) || null, machineNames: item.machines.map(m => m.name || m.fingerprint) });
                });
                res.json({ success: true, data: { total, page, pageSize, list: formattedList } });
            }
            catch (e) {
                res.status(500).json({ error: e.message });
            }
        });
    }
    // 仪表盘统计
    static getStats(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const totalLicenses = yield prisma.license.count();
                // 1. 总绑定设备数 (历史总装机量)
                const totalBoundMachines = yield prisma.machine.count();
                // 2. 实时在线数 (最后活跃在 10 分钟内的)
                const tenMinutesAgo = (0, dayjs_1.default)().subtract(10, 'minute').toDate();
                const onlineMachines = yield prisma.machine.count({
                    where: { lastSeen: { gte: tenMinutesAgo } },
                });
                // 3. 激活的 License
                const activeLicenses = yield prisma.license.count({
                    where: { machines: { some: {} } },
                });
                // 4. 快过期的
                const expiringSoon = yield prisma.license.count({
                    where: {
                        status: enums_1.LicenseStatus.ACTIVE,
                        expiresAt: { lte: (0, dayjs_1.default)().add(7, 'day').toDate(), gte: new Date() },
                    },
                });
                res.json({
                    success: true,
                    data: {
                        totalLicenses,
                        activeLicenses,
                        inactiveLicenses: totalLicenses - activeLicenses,
                        // === 变动字段 ===
                        totalMachines: totalBoundMachines, // 为了兼容旧字段，仍叫 totalMachines，但含义是总装机
                        totalBoundMachines, // 明确的新字段：总装机
                        onlineMachines, // 新字段：实时在线 (前端仪表盘建议显示这个)
                        expiringSoon,
                    },
                });
            }
            catch (e) {
                res.status(500).json({ error: e.message });
            }
        });
    }
    // 设备列表 (反查)
    static listMachines(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const page = parseInt(req.query.page) || 1;
                const pageSize = parseInt(req.query.pageSize) || 10;
                const keyword = req.query.keyword;
                const where = {};
                if (keyword) {
                    where.OR = [
                        { fingerprint: { contains: keyword } },
                        { name: { contains: keyword } },
                        { ip: { contains: keyword } },
                        { license: { key: { contains: keyword } } },
                    ];
                }
                const [total, list] = yield Promise.all([
                    prisma.machine.count({ where }),
                    prisma.machine.findMany({
                        where,
                        skip: (page - 1) * pageSize,
                        take: pageSize,
                        orderBy: { lastSeen: 'desc' },
                        include: {
                            license: {
                                select: { key: true, remark: true, status: true },
                            },
                        },
                    }),
                ]);
                const now = (0, dayjs_1.default)();
                const formattedList = list.map(m => {
                    // 判断逻辑：心跳时间在 10 分钟以内算在线
                    const diffMinutes = now.diff((0, dayjs_1.default)(m.lastSeen), 'minute');
                    const isOnline = diffMinutes < 10;
                    return {
                        id: m.id,
                        fingerprint: m.fingerprint,
                        name: m.name || '未知设备',
                        platform: m.platform,
                        ip: m.ip,
                        lastSeen: m.lastSeen,
                        // === 新增字段 ===
                        isOnline: isOnline, // true=在线(绿), false=离线(灰)
                        offlineDuration: isOnline ? '在线' : `${diffMinutes}分钟前`, // 用于前端显示文本
                        licenseKey: m.license.key,
                        licenseRemark: m.license.remark,
                        licenseStatus: m.license.status,
                    };
                });
                res.json({ success: true, data: { total, page, pageSize, list: formattedList } });
            }
            catch (e) {
                res.status(500).json({ error: e.message });
            }
        });
    }
    // CRUD
    static updateLicense(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { id } = req.params;
                // 1. 解构前端传来的参数
                const { status, remark, maxMachines, strategy, addDays } = req.body;
                // 2. 准备要更新到数据库的对象 (只包含数据库里有的字段)
                const updateData = {};
                if (status)
                    updateData.status = status;
                if (remark)
                    updateData.remark = remark;
                if (maxMachines)
                    updateData.maxMachines = maxMachines;
                if (strategy)
                    updateData.strategy = strategy;
                // 3. 特殊处理：如果有 addDays，则需要计算新的 expiresAt
                if (addDays && typeof addDays === 'number') {
                    // 先查出当前授权码的信息
                    const currentLicense = yield prisma.license.findUnique({ where: { id } });
                    if (currentLicense) {
                        const now = (0, dayjs_1.default)();
                        const currentExpire = currentLicense.expiresAt ? (0, dayjs_1.default)(currentLicense.expiresAt) : now;
                        // 逻辑：如果当前还没过期，就在原过期时间上加；如果已过期，就从今天开始加
                        const baseDate = currentExpire.isAfter(now) ? currentExpire : now;
                        // 计算新的过期时间
                        updateData.expiresAt = baseDate.add(addDays, 'day').toDate();
                        // 如果进行了延期操作，且当前状态是 EXPIRED，自动改为 ACTIVE
                        if (currentLicense.status === enums_1.LicenseStatus.EXPIRED) {
                            updateData.status = enums_1.LicenseStatus.ACTIVE;
                        }
                    }
                }
                // 4. 执行更新 (注意：这里传入的是 updateData，里面没有 addDays 字段了)
                const updated = yield prisma.license.update({
                    where: { id },
                    data: updateData,
                });
                res.json({ success: true, data: updated });
            }
            catch (error) {
                console.error(error); // 打印错误日志方便调试
                res.status(500).json({ success: false, error: error.message });
            }
        });
    }
    static deleteLicense(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            yield prisma.license.delete({ where: { id: req.params.id } });
            res.json({ success: true });
        });
    }
    static resetMachines(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            yield prisma.machine.deleteMany({ where: { licenseId: req.params.id } });
            res.json({ success: true });
        });
    }
}
exports.AdminController = AdminController;
