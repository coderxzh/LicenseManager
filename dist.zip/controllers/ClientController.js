"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientController = void 0;
const LicenseService_1 = require("../services/LicenseService");
const Signer_1 = require("../utils/Signer");
const enums_1 = require("../enums");
class ClientController {
    static validate(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { key, fingerprint, platform, hostname } = req.body;
                const ip = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
                const result = yield LicenseService_1.LicenseService.activate(key, fingerprint, {
                    ip: ip,
                    platform,
                    hostname,
                });
                // 加上签名返回
                res.json((0, Signer_1.signResponse)(Object.assign({ success: true }, result)));
            }
            catch (e) {
                res.status(403).json((0, Signer_1.signResponse)({ success: false, error: e.message }));
            }
        });
    }
    static heartbeat(req, res) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const { key, fingerprint } = req.body;
                yield LicenseService_1.LicenseService.heartbeat(key, fingerprint);
                res.json((0, Signer_1.signResponse)({ success: true, alive: true }));
            }
            catch (e) {
                // [优化] 使用 Enum 判断错误类型
                const code = e.message === enums_1.ErrorCode.KICKED ? 'KICKED' : 'ERROR';
                res.status(403).json((0, Signer_1.signResponse)({ success: false, code, error: e.message }));
            }
        });
    }
}
exports.ClientController = ClientController;
